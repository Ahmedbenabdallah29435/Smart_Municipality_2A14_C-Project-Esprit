#ifndef CONNECTION_H
#define CONNECTION_H


class Connection
{
public:
    Connection();
     bool createConnect();
};

#endif // CONNECTION_H
