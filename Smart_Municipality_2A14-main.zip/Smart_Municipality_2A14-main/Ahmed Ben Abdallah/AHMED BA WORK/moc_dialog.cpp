/****************************************************************************
** Meta object code from reading C++ file 'dialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../Bureau/PROJET VALIDATION/Final_GC/dialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Dialog_t {
    QByteArrayData data[34];
    char stringdata0[786];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Dialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Dialog_t qt_meta_stringdata_Dialog = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Dialog"
QT_MOC_LITERAL(1, 7, 8), // "showTime"
QT_MOC_LITERAL(2, 16, 0), // ""
QT_MOC_LITERAL(3, 17, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(4, 39, 29), // "on_tabWidget_2_currentChanged"
QT_MOC_LITERAL(5, 69, 5), // "index"
QT_MOC_LITERAL(6, 75, 28), // "on_pushButton_delete_clicked"
QT_MOC_LITERAL(7, 104, 26), // "on_pushButton_edit_clicked"
QT_MOC_LITERAL(8, 131, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(9, 155, 31), // "on_pushButton_recherche_clicked"
QT_MOC_LITERAL(10, 187, 22), // "on_tableView_activated"
QT_MOC_LITERAL(11, 210, 22), // "on_radioButton_clicked"
QT_MOC_LITERAL(12, 233, 24), // "on_radioButton_destroyed"
QT_MOC_LITERAL(13, 258, 24), // "on_radioButton_2_clicked"
QT_MOC_LITERAL(14, 283, 32), // "on_pushButton_actualiser_clicked"
QT_MOC_LITERAL(15, 316, 42), // "on_pushButton_sauvgarderreser..."
QT_MOC_LITERAL(16, 359, 29), // "on_tabWidget_3_currentChanged"
QT_MOC_LITERAL(17, 389, 24), // "on_tableView_2_activated"
QT_MOC_LITERAL(18, 414, 41), // "on_pushButton_modifierreserva..."
QT_MOC_LITERAL(19, 456, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(20, 480, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(21, 504, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(22, 528, 30), // "on_slider_progress_sliderMoved"
QT_MOC_LITERAL(23, 559, 8), // "position"
QT_MOC_LITERAL(24, 568, 28), // "on_slider_volume_sliderMoved"
QT_MOC_LITERAL(25, 597, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(26, 621, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(27, 645, 18), // "on_positionChanged"
QT_MOC_LITERAL(28, 664, 18), // "on_durationChanged"
QT_MOC_LITERAL(29, 683, 44), // "on_lineEdit_rechercher_cursor..."
QT_MOC_LITERAL(30, 728, 4), // "arg1"
QT_MOC_LITERAL(31, 733, 4), // "arg2"
QT_MOC_LITERAL(32, 738, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(33, 762, 23) // "on_pushButton_9_clicked"

    },
    "Dialog\0showTime\0\0on_pushButton_clicked\0"
    "on_tabWidget_2_currentChanged\0index\0"
    "on_pushButton_delete_clicked\0"
    "on_pushButton_edit_clicked\0"
    "on_pushButton_2_clicked\0"
    "on_pushButton_recherche_clicked\0"
    "on_tableView_activated\0on_radioButton_clicked\0"
    "on_radioButton_destroyed\0"
    "on_radioButton_2_clicked\0"
    "on_pushButton_actualiser_clicked\0"
    "on_pushButton_sauvgarderreservatio_clicked\0"
    "on_tabWidget_3_currentChanged\0"
    "on_tableView_2_activated\0"
    "on_pushButton_modifierreservation_clicked\0"
    "on_pushButton_3_clicked\0on_pushButton_4_clicked\0"
    "on_pushButton_5_clicked\0"
    "on_slider_progress_sliderMoved\0position\0"
    "on_slider_volume_sliderMoved\0"
    "on_pushButton_6_clicked\0on_pushButton_7_clicked\0"
    "on_positionChanged\0on_durationChanged\0"
    "on_lineEdit_rechercher_cursorPositionChanged\0"
    "arg1\0arg2\0on_pushButton_8_clicked\0"
    "on_pushButton_9_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Dialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x08 /* Private */,
       3,    0,  155,    2, 0x08 /* Private */,
       4,    1,  156,    2, 0x08 /* Private */,
       6,    0,  159,    2, 0x08 /* Private */,
       7,    0,  160,    2, 0x08 /* Private */,
       8,    0,  161,    2, 0x08 /* Private */,
       9,    0,  162,    2, 0x08 /* Private */,
      10,    1,  163,    2, 0x08 /* Private */,
      11,    0,  166,    2, 0x08 /* Private */,
      12,    0,  167,    2, 0x08 /* Private */,
      13,    0,  168,    2, 0x08 /* Private */,
      14,    0,  169,    2, 0x08 /* Private */,
      15,    0,  170,    2, 0x08 /* Private */,
      16,    1,  171,    2, 0x08 /* Private */,
      17,    1,  174,    2, 0x08 /* Private */,
      18,    0,  177,    2, 0x08 /* Private */,
      19,    0,  178,    2, 0x08 /* Private */,
      20,    0,  179,    2, 0x08 /* Private */,
      21,    0,  180,    2, 0x08 /* Private */,
      22,    1,  181,    2, 0x08 /* Private */,
      24,    1,  184,    2, 0x08 /* Private */,
      25,    0,  187,    2, 0x08 /* Private */,
      26,    0,  188,    2, 0x08 /* Private */,
      27,    1,  189,    2, 0x08 /* Private */,
      28,    1,  192,    2, 0x08 /* Private */,
      29,    2,  195,    2, 0x08 /* Private */,
      32,    0,  200,    2, 0x08 /* Private */,
      33,    0,  201,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::QModelIndex,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::LongLong,   23,
    QMetaType::Void, QMetaType::LongLong,   23,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   30,   31,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Dialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Dialog *_t = static_cast<Dialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->showTime(); break;
        case 1: _t->on_pushButton_clicked(); break;
        case 2: _t->on_tabWidget_2_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_pushButton_delete_clicked(); break;
        case 4: _t->on_pushButton_edit_clicked(); break;
        case 5: _t->on_pushButton_2_clicked(); break;
        case 6: _t->on_pushButton_recherche_clicked(); break;
        case 7: _t->on_tableView_activated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 8: _t->on_radioButton_clicked(); break;
      //  case 9: _t->on_radioButton_destroyed(); break;
        case 10: _t->on_radioButton_2_clicked(); break;
        case 11: _t->on_pushButton_actualiser_clicked(); break;
        case 12: _t->on_pushButton_sauvgarderreservatio_clicked(); break;
        case 13: _t->on_tabWidget_3_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_tableView_2_activated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 15: _t->on_pushButton_modifierreservation_clicked(); break;
        case 16: _t->on_pushButton_3_clicked(); break;
        case 17: _t->on_pushButton_4_clicked(); break;
        case 18: _t->on_pushButton_5_clicked(); break;
        case 19: _t->on_slider_progress_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_slider_volume_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_pushButton_6_clicked(); break;
        case 22: _t->on_pushButton_7_clicked(); break;
        case 23: _t->on_positionChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 24: _t->on_durationChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        //case 25: _t->on_lineEdit_rechercher_cursorPositionChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 26: _t->on_pushButton_8_clicked(); break;
       // case 27: _t->on_pushButton_9_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject Dialog::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Dialog.data,
      qt_meta_data_Dialog,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Dialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Dialog.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Dialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
