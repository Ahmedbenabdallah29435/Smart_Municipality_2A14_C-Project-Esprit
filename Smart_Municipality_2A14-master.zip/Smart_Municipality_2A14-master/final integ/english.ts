<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="fr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="550"/>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="827"/>
        <source>Municipality</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="873"/>
        <source>Minimize</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="905"/>
        <source>Maximize</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="937"/>
        <source>Close</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1033"/>
        <source>| HOME</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1185"/>
        <location filename="mainwindow.ui" line="1450"/>
        <source>Open File</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1232"/>
        <source>Save</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1279"/>
        <source>New</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1556"/>
        <source>Created by: Wanderson M. Pimenta</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1665"/>
        <source>USER</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1706"/>
        <source>PASSWORD</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1738"/>
        <source>SAVE USER</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1767"/>
        <source>CONNECT</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1830"/>
        <source>Welcome to our project</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1868"/>
        <source>gestion projet</source>
        <translation>project management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1901"/>
        <source>gestion de transport</source>
        <translation>transport management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1934"/>
        <source>gestion des equipements</source>
        <translation>equipment management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1967"/>
        <source>gestion financiere</source>
        <translation>financial management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2000"/>
        <source>gestion idvidus</source>
        <translation>management individuals</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2033"/>
        <source>gestion des agents</source>
        <translation>agent management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2119"/>
        <source>Ajouter agent</source>
        <translation>add agent</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2134"/>
        <location filename="mainwindow.ui" line="3172"/>
        <location filename="mainwindow.ui" line="3237"/>
        <location filename="mainwindow.ui" line="3969"/>
        <source>CIN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2150"/>
        <location filename="mainwindow.ui" line="3706"/>
        <location filename="mainwindow.ui" line="6539"/>
        <location filename="mainwindow.ui" line="6722"/>
        <location filename="mainwindow.ui" line="7178"/>
        <location filename="mainwindow.ui" line="7430"/>
        <location filename="mainwindow.ui" line="8316"/>
        <source>Nom</source>
        <translation>last name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2166"/>
        <location filename="mainwindow.ui" line="3953"/>
        <source>Prenom</source>
        <translation>first name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2182"/>
        <source>Date de naissance</source>
        <translation>Date of Birth</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2198"/>
        <location filename="mainwindow.ui" line="3722"/>
        <location filename="mainwindow.ui" line="7217"/>
        <location filename="mainwindow.ui" line="7729"/>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2214"/>
        <location filename="mainwindow.ui" line="3252"/>
        <location filename="mainwindow.ui" line="3873"/>
        <source>tel</source>
        <translation>numero</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2230"/>
        <location filename="mainwindow.ui" line="3985"/>
        <source>Profil</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2413"/>
        <location filename="mainwindow.ui" line="2792"/>
        <location filename="mainwindow.ui" line="4680"/>
        <location filename="mainwindow.ui" line="6514"/>
        <location filename="mainwindow.ui" line="6639"/>
        <location filename="mainwindow.ui" line="7324"/>
        <location filename="mainwindow.ui" line="8425"/>
        <location filename="mainwindow.ui" line="9329"/>
        <location filename="mainwindow.ui" line="9955"/>
        <location filename="mainwindow.ui" line="10458"/>
        <location filename="mainwindow.ui" line="11773"/>
        <location filename="mainwindow.ui" line="12487"/>
        <source>Ajouter</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2555"/>
        <source>Ajouter profil</source>
        <translation>Add profil</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2587"/>
        <location filename="mainwindow.ui" line="3435"/>
        <location filename="mainwindow.ui" line="3487"/>
        <location filename="mainwindow.ui" line="4204"/>
        <location filename="mainwindow.ui" line="8381"/>
        <location filename="mainwindow.ui" line="11979"/>
        <location filename="mainwindow.ui" line="12366"/>
        <source>ID</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2600"/>
        <source>nom_profil</source>
        <translation>Date of Birth</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2613"/>
        <location filename="mainwindow.ui" line="4348"/>
        <source>Salaire</source>
        <translation>salary</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2626"/>
        <location filename="mainwindow.ui" line="4335"/>
        <location filename="mainwindow.ui" line="6565"/>
        <location filename="mainwindow.ui" line="7337"/>
        <location filename="mainwindow.ui" line="7612"/>
        <location filename="mainwindow.ui" line="10489"/>
        <source>Description</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2639"/>
        <location filename="mainwindow.ui" line="4361"/>
        <source>Nombre des agents</source>
        <translation>number of agnets</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2928"/>
        <source>Afficher les agents</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2985"/>
        <location filename="mainwindow.ui" line="3350"/>
        <location filename="mainwindow.ui" line="12292"/>
        <source>Chercher</source>
        <translation>search</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3018"/>
        <location filename="mainwindow.ui" line="3569"/>
        <location filename="mainwindow.ui" line="6847"/>
        <location filename="mainwindow.ui" line="7498"/>
        <location filename="mainwindow.ui" line="8766"/>
        <location filename="mainwindow.ui" line="10843"/>
        <location filename="mainwindow.ui" line="11545"/>
        <source>Imprimer</source>
        <translation>print</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3051"/>
        <location filename="mainwindow.ui" line="3383"/>
        <location filename="mainwindow.ui" line="4998"/>
        <location filename="mainwindow.ui" line="6196"/>
        <location filename="mainwindow.ui" line="6984"/>
        <location filename="mainwindow.ui" line="7030"/>
        <location filename="mainwindow.ui" line="7828"/>
        <location filename="mainwindow.ui" line="8678"/>
        <location filename="mainwindow.ui" line="9648"/>
        <location filename="mainwindow.ui" line="10149"/>
        <location filename="mainwindow.ui" line="10639"/>
        <location filename="mainwindow.ui" line="11168"/>
        <location filename="mainwindow.ui" line="11851"/>
        <source>Supprimer</source>
        <translation>delete</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3085"/>
        <location filename="mainwindow.ui" line="3602"/>
        <location filename="mainwindow.ui" line="6756"/>
        <location filename="mainwindow.ui" line="7396"/>
        <location filename="mainwindow.ui" line="9692"/>
        <source>Actualiser</source>
        <translation>refresh</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3159"/>
        <location filename="mainwindow.ui" line="3536"/>
        <location filename="mainwindow.ui" line="5446"/>
        <location filename="mainwindow.ui" line="6312"/>
        <location filename="mainwindow.ui" line="8722"/>
        <source>PDF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3185"/>
        <location filename="mainwindow.ui" line="3247"/>
        <location filename="mainwindow.ui" line="6006"/>
        <location filename="mainwindow.ui" line="11200"/>
        <location filename="mainwindow.ui" line="11596"/>
        <source>prenom</source>
        <translation>first name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3198"/>
        <source>email</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3232"/>
        <location filename="mainwindow.ui" line="3482"/>
        <source>trier par</source>
        <translation>sort by</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3242"/>
        <location filename="mainwindow.ui" line="6230"/>
        <location filename="mainwindow.ui" line="8211"/>
        <location filename="mainwindow.ui" line="11344"/>
        <location filename="mainwindow.ui" line="11612"/>
        <source>nom</source>
        <translation>last name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3286"/>
        <location filename="mainwindow.ui" line="10366"/>
        <source>Statistique</source>
        <translation>statistical</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3293"/>
        <source>Afficher les profils</source>
        <translation>show profiles</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3448"/>
        <location filename="mainwindow.ui" line="3497"/>
        <source>salaire</source>
        <translation>salary</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3492"/>
        <source>nom profil</source>
        <translation>profil name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3502"/>
        <source>nombre des agents</source>
        <translation>number of agent</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3673"/>
        <source>Modifier agent</source>
        <translation>edit agent</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3809"/>
        <location filename="mainwindow.ui" line="4261"/>
        <location filename="mainwindow.ui" line="4964"/>
        <location filename="mainwindow.ui" line="6138"/>
        <location filename="mainwindow.ui" line="6978"/>
        <location filename="mainwindow.ui" line="7776"/>
        <location filename="mainwindow.ui" line="8478"/>
        <location filename="mainwindow.ui" line="9382"/>
        <location filename="mainwindow.ui" line="10121"/>
        <location filename="mainwindow.ui" line="10165"/>
        <location filename="mainwindow.ui" line="10595"/>
        <location filename="mainwindow.ui" line="10623"/>
        <location filename="mainwindow.ui" line="11393"/>
        <location filename="mainwindow.ui" line="12177"/>
        <source>Modifier</source>
        <translation>edit</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3889"/>
        <location filename="mainwindow.ui" line="11360"/>
        <source>date de naissance</source>
        <translation>date of birth</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4126"/>
        <source>Modifier profil</source>
        <translation>edit profil</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4322"/>
        <source>nom_Profil</source>
        <translation>profil name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4486"/>
        <source>GESTION DE TRANSPORT : </source>
        <translation>transport management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4550"/>
        <source>moyens de transport</source>
        <translation>means of transport</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4623"/>
        <source>Ajouter moyen</source>
        <translation>add way</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4701"/>
        <location filename="mainwindow.ui" line="5190"/>
        <source>model :</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4722"/>
        <location filename="mainwindow.ui" line="5169"/>
        <source>ref:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4746"/>
        <location filename="mainwindow.ui" line="5214"/>
        <source>confort :</source>
        <translation>comfort</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4770"/>
        <location filename="mainwindow.ui" line="5148"/>
        <source>nombres de places :</source>
        <translation>number of place</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4824"/>
        <location filename="mainwindow.ui" line="5238"/>
        <source>climatisation :</source>
        <translation>air conditioner</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4906"/>
        <location filename="mainwindow.ui" line="5406"/>
        <source>VOITURE</source>
        <translation>car</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4911"/>
        <location filename="mainwindow.ui" line="5411"/>
        <source>BUS</source>
        <translation>bus</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4918"/>
        <source>Afficher moyen</source>
        <translation>display way</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5272"/>
        <location filename="mainwindow.ui" line="5863"/>
        <source>Refreche</source>
        <translation>search</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5306"/>
        <location filename="mainwindow.ui" line="5966"/>
        <location filename="mainwindow.ui" line="9530"/>
        <source>Rechercher</source>
        <translation>search</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5311"/>
        <location filename="mainwindow.ui" line="5361"/>
        <location filename="mainwindow.ui" line="5932"/>
        <source>ref</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5316"/>
        <source>modele et confort</source>
        <translation>model and comfort</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5321"/>
        <source>modele et nombre_de_place et confort</source>
        <translation>model,number of place, comfort</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5356"/>
        <location filename="mainwindow.ui" line="6064"/>
        <source>Trier </source>
        <translation>sort by</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5366"/>
        <source>modele</source>
        <translation>model</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5371"/>
        <source>modele et nombre de place </source>
        <translation>model and number of place</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5480"/>
        <location filename="mainwindow.ui" line="6346"/>
        <source>IMPRIMER</source>
        <translation>print</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5486"/>
        <source>réclamation :</source>
        <translation>reclamation</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5501"/>
        <source>gestion abonnements</source>
        <translation>subscription management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5566"/>
        <source>ajouter abonné</source>
        <translation>add subscriber</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5610"/>
        <source>ID:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5631"/>
        <source>NOM:</source>
        <translation>last name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5700"/>
        <source>prenom :</source>
        <translation>first name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5721"/>
        <source>ref moyen :</source>
        <translation>ref way</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5742"/>
        <source>payer :</source>
        <translation>pay</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5824"/>
        <location filename="mainwindow.ui" line="7153"/>
        <source>ajouter</source>
        <translation>add</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5830"/>
        <source>afficher abonne</source>
        <translation>display subcriber</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5908"/>
        <location filename="mainwindow.ui" line="5971"/>
        <location filename="mainwindow.ui" line="6069"/>
        <location filename="mainwindow.ui" line="8188"/>
        <source>id</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5976"/>
        <source>nom et prenom </source>
        <translation>last name and first name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5981"/>
        <location filename="mainwindow.ui" line="6079"/>
        <source>ref_moy et nom et prenom</source>
        <translation>ref_way and last name and first name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6030"/>
        <source>payment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6074"/>
        <source>nom et prenom</source>
        <translation>last name and first name</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6387"/>
        <source>Gestion des projets</source>
        <translation>project management</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6421"/>
        <location filename="mainwindow.ui" line="6436"/>
        <source>Gestion des catégories</source>
        <translation>categories mangment</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6526"/>
        <source>id </source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6552"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6645"/>
        <location filename="mainwindow.ui" line="7353"/>
        <source>afficher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6688"/>
        <location filename="mainwindow.ui" line="7464"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6790"/>
        <location filename="mainwindow.ui" line="7555"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6803"/>
        <source>Nom à chercher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6853"/>
        <location filename="mainwindow.ui" line="7561"/>
        <source>modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6865"/>
        <source>Id du catégorie à modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6878"/>
        <source>Nouveau nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6891"/>
        <source>Nouveau type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6904"/>
        <source>Nouveau description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6996"/>
        <source>ID du categorie à supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7165"/>
        <source>Id projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7191"/>
        <source>Emplacement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7204"/>
        <location filename="mainwindow.ui" line="7716"/>
        <source>Lieu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7230"/>
        <location filename="mainwindow.ui" line="7677"/>
        <source>Contenue </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7511"/>
        <source>Nom a chercher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7599"/>
        <source>nouveau Emplacement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7625"/>
        <source>Id projet à modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7638"/>
        <source>nouveau nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7782"/>
        <source>supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7794"/>
        <source>Id du projet à supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7853"/>
        <source>Gestion de projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8068"/>
        <source>Equipements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8148"/>
        <source>Ajouter  Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8234"/>
        <source>nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8257"/>
        <source>adresse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8280"/>
        <source>prix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8303"/>
        <source>marque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8329"/>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8342"/>
        <source>Adresse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8355"/>
        <location filename="mainwindow.ui" line="12111"/>
        <location filename="mainwindow.ui" line="12382"/>
        <source>Prix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8368"/>
        <source>Marque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8510"/>
        <source>Afficher Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8634"/>
        <source>Acualiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8784"/>
        <source>Organisation par Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8806"/>
        <source>Ajouter Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8915"/>
        <source>  ID                             </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8936"/>
        <source>Nom Bloc                           </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8957"/>
        <source>Equipment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8978"/>
        <source>Type Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8999"/>
        <source>Numéro                     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9020"/>
        <source>date </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9054"/>
        <source>ID de 6 chiffres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9089"/>
        <source>NOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9123"/>
        <source>equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9156"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9190"/>
        <source>NUMERO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9224"/>
        <source>JJ/MM/AAAA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9245"/>
        <source>Situation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9279"/>
        <source>En marche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9284"/>
        <source>En panne</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9398"/>
        <source>Afficher Equipements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9563"/>
        <source>ID/NOM/PRENOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9588"/>
        <source>Tri par ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9613"/>
        <source>Tri par nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9736"/>
        <source>Start Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9752"/>
        <source>Stop Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9936"/>
        <source>Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9970"/>
        <location filename="mainwindow.ui" line="10217"/>
        <location filename="mainwindow.ui" line="10707"/>
        <source>ID Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9986"/>
        <location filename="mainwindow.ui" line="10237"/>
        <location filename="mainwindow.ui" line="10727"/>
        <source>Tel Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10002"/>
        <location filename="mainwindow.ui" line="10232"/>
        <location filename="mainwindow.ui" line="10722"/>
        <source>Email Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10018"/>
        <source>Adresse Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10034"/>
        <location filename="mainwindow.ui" line="10222"/>
        <location filename="mainwindow.ui" line="10712"/>
        <source>Nom Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10115"/>
        <location filename="mainwindow.ui" line="10589"/>
        <source>AJOUTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10182"/>
        <location filename="mainwindow.ui" line="10672"/>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10187"/>
        <location filename="mainwindow.ui" line="10677"/>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10192"/>
        <location filename="mainwindow.ui" line="10682"/>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10197"/>
        <location filename="mainwindow.ui" line="10687"/>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10202"/>
        <location filename="mainwindow.ui" line="10692"/>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10207"/>
        <location filename="mainwindow.ui" line="10697"/>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10212"/>
        <location filename="mainwindow.ui" line="10702"/>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10227"/>
        <location filename="mainwindow.ui" line="10717"/>
        <source>Adr. Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10242"/>
        <location filename="mainwindow.ui" line="10732"/>
        <source>1354841</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10247"/>
        <location filename="mainwindow.ui" line="10737"/>
        <source>azoebfakz</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10252"/>
        <location filename="mainwindow.ui" line="10742"/>
        <source>azefazf</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10257"/>
        <location filename="mainwindow.ui" line="10747"/>
        <source>azhef@gmail.com</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10262"/>
        <location filename="mainwindow.ui" line="10752"/>
        <source>58796431</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10279"/>
        <location filename="mainwindow.ui" line="10418"/>
        <source>Recherche par ID</source>
        <translation>search by ID</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10335"/>
        <location filename="mainwindow.ui" line="10799"/>
        <source>Afficher</source>
        <translation>Display</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10350"/>
        <location filename="mainwindow.ui" line="10827"/>
        <source>Affichage</source>
        <translation>Display</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10380"/>
        <source>Par nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10385"/>
        <source>Par adresse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10390"/>
        <source>Par tel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10439"/>
        <source>Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10473"/>
        <source>Code Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10505"/>
        <source>Montantnet de Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10521"/>
        <source>Date de Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10655"/>
        <location filename="mainwindow.ui" line="10889"/>
        <source>Recherche par code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10857"/>
        <source>Par date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10862"/>
        <source>Par montant net</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10944"/>
        <source>Individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10977"/>
        <source>Logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11010"/>
        <location filename="mainwindow.ui" line="11076"/>
        <source>AJOUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11043"/>
        <location filename="mainwindow.ui" line="11109"/>
        <source>AFFICHAGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11184"/>
        <location filename="mainwindow.ui" line="11328"/>
        <location filename="mainwindow.ui" line="11580"/>
        <source>cin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11240"/>
        <location filename="mainwindow.ui" line="11628"/>
        <source>idl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11502"/>
        <location filename="mainwindow.ui" line="11806"/>
        <location filename="mainwindow.ui" line="12144"/>
        <location filename="mainwindow.ui" line="12520"/>
        <source>Retour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11644"/>
        <source>date de naissace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11891"/>
        <location filename="mainwindow.ui" line="12334"/>
        <source>NomF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12019"/>
        <location filename="mainwindow.ui" line="12350"/>
        <source>Secteur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12193"/>
        <source>ID </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12226"/>
        <source>Trier par prix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12259"/>
        <source>Trier par id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12626"/>
        <source>v1.0.0</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="Blocc.cpp" line="51"/>
        <location filename="categorie.cpp" line="106"/>
        <location filename="categorie.cpp" line="121"/>
        <location filename="categorie.cpp" line="137"/>
        <location filename="categorie.cpp" line="150"/>
        <location filename="categorie.cpp" line="163"/>
        <location filename="categorie.cpp" line="174"/>
        <location filename="profil.cpp" line="85"/>
        <location filename="projet.cpp" line="133"/>
        <location filename="projet.cpp" line="151"/>
        <location filename="projet.cpp" line="170"/>
        <location filename="projet.cpp" line="186"/>
        <location filename="projet.cpp" line="202"/>
        <location filename="projet.cpp" line="216"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="52"/>
        <source>NOM_BLOC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="53"/>
        <source>EQUIPMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="54"/>
        <source>TYPE_EQUIPEMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="55"/>
        <source>NUMERO_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="56"/>
        <source>DATE_A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="57"/>
        <source>SITUATION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="62"/>
        <location filename="abonnement.cpp" line="157"/>
        <location filename="abonnement.cpp" line="176"/>
        <location filename="abonnement.cpp" line="191"/>
        <location filename="logement.cpp" line="65"/>
        <location filename="logement.cpp" line="98"/>
        <location filename="logement.cpp" line="109"/>
        <location filename="logement.cpp" line="119"/>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="63"/>
        <location filename="abonnement.cpp" line="158"/>
        <location filename="abonnement.cpp" line="177"/>
        <location filename="abonnement.cpp" line="192"/>
        <location filename="individus.cpp" line="70"/>
        <source>nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="64"/>
        <location filename="abonnement.cpp" line="159"/>
        <location filename="abonnement.cpp" line="178"/>
        <location filename="abonnement.cpp" line="193"/>
        <location filename="individus.cpp" line="71"/>
        <source>prenom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="65"/>
        <location filename="abonnement.cpp" line="160"/>
        <location filename="abonnement.cpp" line="179"/>
        <location filename="abonnement.cpp" line="194"/>
        <source>ref_moy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="66"/>
        <location filename="abonnement.cpp" line="161"/>
        <location filename="abonnement.cpp" line="180"/>
        <location filename="abonnement.cpp" line="195"/>
        <source>payement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="254"/>
        <source>CIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="255"/>
        <location filename="categorie.cpp" line="107"/>
        <location filename="categorie.cpp" line="122"/>
        <location filename="categorie.cpp" line="138"/>
        <location filename="categorie.cpp" line="151"/>
        <location filename="categorie.cpp" line="164"/>
        <location filename="categorie.cpp" line="175"/>
        <location filename="projet.cpp" line="134"/>
        <location filename="projet.cpp" line="152"/>
        <location filename="projet.cpp" line="171"/>
        <location filename="projet.cpp" line="187"/>
        <location filename="projet.cpp" line="203"/>
        <location filename="projet.cpp" line="217"/>
        <source>NOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="256"/>
        <source>PRENOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="257"/>
        <source>DATE_NAISSANCE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="258"/>
        <location filename="projet.cpp" line="137"/>
        <location filename="projet.cpp" line="155"/>
        <location filename="projet.cpp" line="174"/>
        <location filename="projet.cpp" line="190"/>
        <location filename="projet.cpp" line="206"/>
        <location filename="projet.cpp" line="220"/>
        <source>EMAIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="259"/>
        <source>TEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="260"/>
        <location filename="profil.cpp" line="86"/>
        <source>NOM_PROFIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="categorie.cpp" line="108"/>
        <location filename="categorie.cpp" line="123"/>
        <location filename="categorie.cpp" line="139"/>
        <location filename="categorie.cpp" line="152"/>
        <location filename="categorie.cpp" line="165"/>
        <location filename="categorie.cpp" line="176"/>
        <source>TYPE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="categorie.cpp" line="109"/>
        <location filename="categorie.cpp" line="124"/>
        <location filename="categorie.cpp" line="140"/>
        <location filename="categorie.cpp" line="153"/>
        <location filename="categorie.cpp" line="166"/>
        <location filename="categorie.cpp" line="177"/>
        <location filename="profil.cpp" line="88"/>
        <location filename="projet.cpp" line="139"/>
        <location filename="projet.cpp" line="157"/>
        <location filename="projet.cpp" line="176"/>
        <location filename="projet.cpp" line="192"/>
        <location filename="projet.cpp" line="208"/>
        <location filename="projet.cpp" line="222"/>
        <source>DESCRIPTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="35"/>
        <location filename="devis.cpp" line="59"/>
        <location filename="devis.cpp" line="93"/>
        <source>CODE_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="36"/>
        <location filename="devis.cpp" line="60"/>
        <location filename="devis.cpp" line="95"/>
        <source>MONTNET_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="37"/>
        <location filename="devis.cpp" line="61"/>
        <location filename="devis.cpp" line="96"/>
        <source>DESC_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="38"/>
        <location filename="devis.cpp" line="62"/>
        <location filename="devis.cpp" line="94"/>
        <source>DATE_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="38"/>
        <location filename="fournisseur.cpp" line="63"/>
        <location filename="fournisseur.cpp" line="83"/>
        <source>ID_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="39"/>
        <location filename="fournisseur.cpp" line="64"/>
        <location filename="fournisseur.cpp" line="84"/>
        <source>NOM_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="40"/>
        <location filename="fournisseur.cpp" line="85"/>
        <source>ADRESSE_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="41"/>
        <location filename="fournisseur.cpp" line="67"/>
        <location filename="fournisseur.cpp" line="86"/>
        <source>EMAIL_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="42"/>
        <location filename="fournisseur.cpp" line="65"/>
        <location filename="fournisseur.cpp" line="87"/>
        <source>TEL_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="66"/>
        <source>ADRESSE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="61"/>
        <location filename="gestionmoyen.cpp" line="155"/>
        <location filename="gestionmoyen.cpp" line="174"/>
        <location filename="gestionmoyen.cpp" line="189"/>
        <source>ref</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="62"/>
        <location filename="gestionmoyen.cpp" line="156"/>
        <location filename="gestionmoyen.cpp" line="175"/>
        <location filename="gestionmoyen.cpp" line="190"/>
        <source>modele</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="63"/>
        <location filename="gestionmoyen.cpp" line="157"/>
        <location filename="gestionmoyen.cpp" line="176"/>
        <location filename="gestionmoyen.cpp" line="191"/>
        <source>confort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="64"/>
        <location filename="gestionmoyen.cpp" line="158"/>
        <location filename="gestionmoyen.cpp" line="177"/>
        <location filename="gestionmoyen.cpp" line="192"/>
        <source>nombre_de_place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="65"/>
        <location filename="gestionmoyen.cpp" line="159"/>
        <location filename="gestionmoyen.cpp" line="178"/>
        <location filename="gestionmoyen.cpp" line="193"/>
        <source>climatisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="individus.cpp" line="69"/>
        <source>cin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="individus.cpp" line="72"/>
        <source>date de naissance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="individus.cpp" line="73"/>
        <source>idl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logement.cpp" line="66"/>
        <location filename="logement.cpp" line="99"/>
        <location filename="logement.cpp" line="110"/>
        <location filename="logement.cpp" line="120"/>
        <source>nomf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logement.cpp" line="67"/>
        <location filename="logement.cpp" line="100"/>
        <location filename="logement.cpp" line="111"/>
        <location filename="logement.cpp" line="121"/>
        <source>secteur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logement.cpp" line="68"/>
        <location filename="logement.cpp" line="101"/>
        <location filename="logement.cpp" line="112"/>
        <location filename="logement.cpp" line="122"/>
        <source>price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="17"/>
        <source>database is open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="18"/>
        <source>connection successful.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="22"/>
        <source>database is not open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="23"/>
        <source>connection failed.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="182"/>
        <source>Ajouter un employe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="183"/>
        <source>employe ajouté.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="195"/>
        <source>Ajouter un employé</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="196"/>
        <location filename="mainwindow.cpp" line="439"/>
        <location filename="mainwindow.cpp" line="1237"/>
        <location filename="mainwindow.cpp" line="1262"/>
        <location filename="mainwindow.cpp" line="1284"/>
        <location filename="mainwindow.cpp" line="1365"/>
        <location filename="mainwindow.cpp" line="1393"/>
        <location filename="mainwindow.cpp" line="1415"/>
        <source>Erreur !.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="425"/>
        <location filename="mainwindow.cpp" line="438"/>
        <source>Ajouter profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="426"/>
        <source>profil ajouté.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1230"/>
        <location filename="mainwindow.cpp" line="1236"/>
        <source>Ajouter une Categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1231"/>
        <source>Categorie ajoutée.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1255"/>
        <location filename="mainwindow.cpp" line="1261"/>
        <source>Modifier une Categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1256"/>
        <source>Categorie modifiée.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1277"/>
        <location filename="mainwindow.cpp" line="1283"/>
        <source>Supprimer une Categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1278"/>
        <source>Categorie supprimée.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1328"/>
        <location filename="mainwindow.cpp" line="1458"/>
        <source>PDF echoue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1328"/>
        <location filename="mainwindow.cpp" line="1458"/>
        <source>click cancel to exit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1358"/>
        <location filename="mainwindow.cpp" line="1364"/>
        <source>Ajouter un Projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1359"/>
        <source>Projet ajouté.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1386"/>
        <location filename="mainwindow.cpp" line="1392"/>
        <source>Modifier un Projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1387"/>
        <source>Projet modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1408"/>
        <location filename="mainwindow.cpp" line="1414"/>
        <source>Supprimer un Projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1409"/>
        <source>Projet supprimé.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1552"/>
        <location filename="mainwindow.cpp" line="1556"/>
        <location filename="mainwindow.cpp" line="1561"/>
        <location filename="mainwindow.cpp" line="1566"/>
        <location filename="mainwindow.cpp" line="1571"/>
        <location filename="mainwindow.cpp" line="1577"/>
        <location filename="mainwindow.cpp" line="1583"/>
        <location filename="mainwindow.cpp" line="1594"/>
        <location filename="mainwindow.cpp" line="1600"/>
        <source>Ajouter un Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1553"/>
        <location filename="mainwindow.cpp" line="1785"/>
        <source>ID Doit contenir 6 chifres.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1557"/>
        <location filename="mainwindow.cpp" line="1562"/>
        <location filename="mainwindow.cpp" line="1572"/>
        <location filename="mainwindow.cpp" line="1789"/>
        <location filename="mainwindow.cpp" line="1796"/>
        <location filename="mainwindow.cpp" line="1800"/>
        <location filename="mainwindow.cpp" line="1805"/>
        <location filename="mainwindow.cpp" line="1810"/>
        <source>Veuillez remplir tous les cases.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1567"/>
        <source>Veuillez saisir correctement le numero.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1578"/>
        <source>Veuillez saisir la date sous forme jj/mm/aaaa.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1584"/>
        <source>Veuillez saisir la categorie.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1595"/>
        <source>Client ajouté .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1601"/>
        <location filename="mainwindow.cpp" line="1649"/>
        <location filename="mainwindow.cpp" line="1687"/>
        <source>Erreur.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1641"/>
        <location filename="mainwindow.cpp" line="1648"/>
        <source>Supprimer un Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1642"/>
        <source>Client sumprié .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1679"/>
        <source>Modifier un Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1680"/>
        <source>Client Modifié .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1686"/>
        <source>Modifier un BLoc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1726"/>
        <source>Sélectionner un Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1727"/>
        <location filename="mainwindow.cpp" line="1902"/>
        <source>Erreur .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1784"/>
        <location filename="mainwindow.cpp" line="1788"/>
        <location filename="mainwindow.cpp" line="1795"/>
        <location filename="mainwindow.cpp" line="1799"/>
        <location filename="mainwindow.cpp" line="1804"/>
        <location filename="mainwindow.cpp" line="1809"/>
        <location filename="mainwindow.cpp" line="1819"/>
        <location filename="mainwindow.cpp" line="1825"/>
        <source>Ajouter Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1820"/>
        <source>Equipement ajoutée .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1826"/>
        <source>ERooR .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1870"/>
        <location filename="mainwindow.cpp" line="1877"/>
        <source>Modifier Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1871"/>
        <source>Equipement Modifié .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1878"/>
        <source>ereur .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1894"/>
        <location filename="mainwindow.cpp" line="1901"/>
        <source>Supprimer Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1895"/>
        <source>Equipement supprimé .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2030"/>
        <location filename="mainwindow.cpp" line="2096"/>
        <location filename="mainwindow.cpp" line="2407"/>
        <source>erreur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2031"/>
        <location filename="mainwindow.cpp" line="2097"/>
        <source>Ajout non effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2224"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2224"/>
        <source> Erreur idl necessite 4 chiffres.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2232"/>
        <source>ajouter individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2232"/>
        <source>individus ajouté.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2248"/>
        <source>supprimer individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2248"/>
        <source>individus supprimé.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2271"/>
        <location filename="mainwindow.cpp" line="2278"/>
        <source>modifier individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2272"/>
        <source>individus modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2279"/>
        <location filename="mainwindow.cpp" line="2443"/>
        <source>Erreur.
click cancel to exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2407"/>
        <source>id incomplet.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2414"/>
        <source>ajouter logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2414"/>
        <source>logement ajouté.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2435"/>
        <location filename="mainwindow.cpp" line="2442"/>
        <source>modifier logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2436"/>
        <source>logement modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2457"/>
        <source>supprimer logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2457"/>
        <source>logement supprimé.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profil.cpp" line="87"/>
        <source>SALAIRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profil.cpp" line="89"/>
        <source>NB_AGNETS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="projet.cpp" line="135"/>
        <location filename="projet.cpp" line="153"/>
        <location filename="projet.cpp" line="172"/>
        <location filename="projet.cpp" line="188"/>
        <location filename="projet.cpp" line="204"/>
        <location filename="projet.cpp" line="218"/>
        <source>EMPLACEMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="projet.cpp" line="136"/>
        <location filename="projet.cpp" line="154"/>
        <location filename="projet.cpp" line="173"/>
        <location filename="projet.cpp" line="189"/>
        <location filename="projet.cpp" line="205"/>
        <location filename="projet.cpp" line="219"/>
        <source>LIEU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="projet.cpp" line="138"/>
        <location filename="projet.cpp" line="156"/>
        <location filename="projet.cpp" line="175"/>
        <location filename="projet.cpp" line="191"/>
        <location filename="projet.cpp" line="207"/>
        <location filename="projet.cpp" line="221"/>
        <source>CONTENUE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <location filename="mainwindow.cpp" line="2025"/>
        <location filename="mainwindow.cpp" line="2091"/>
        <source>Ajout effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statistiques</name>
    <message>
        <location filename="statistiques.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
