<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar" sourcelanguage="fr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="550"/>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="827"/>
        <source>Municipality</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="873"/>
        <source>Minimize</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="905"/>
        <source>Maximize</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="937"/>
        <source>Close</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1033"/>
        <source>| HOME</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1185"/>
        <location filename="mainwindow.ui" line="1450"/>
        <source>Open File</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1232"/>
        <source>Save</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1279"/>
        <source>New</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1556"/>
        <source>Created by: Wanderson M. Pimenta</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1665"/>
        <source>USER</source>
        <translation>اسم المستخدم
</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1706"/>
        <source>PASSWORD</source>
        <translation>كلمه السر
</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1738"/>
        <source>SAVE USER</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1767"/>
        <source>CONNECT</source>
        <translation>الاتصال</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1830"/>
        <source>Welcome to our project</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1868"/>
        <source>gestion projet</source>
        <translation>ادارة مشروع</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1901"/>
        <source>gestion de transport</source>
        <translation>إدارة النقل</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1934"/>
        <source>gestion des equipements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1967"/>
        <source>gestion financiere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2000"/>
        <source>gestion idvidus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2033"/>
        <source>gestion des agents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2119"/>
        <source>Ajouter agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2134"/>
        <location filename="mainwindow.ui" line="3172"/>
        <location filename="mainwindow.ui" line="3237"/>
        <location filename="mainwindow.ui" line="3969"/>
        <source>CIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2150"/>
        <location filename="mainwindow.ui" line="3706"/>
        <location filename="mainwindow.ui" line="6539"/>
        <location filename="mainwindow.ui" line="6722"/>
        <location filename="mainwindow.ui" line="7178"/>
        <location filename="mainwindow.ui" line="7430"/>
        <location filename="mainwindow.ui" line="8316"/>
        <source>Nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2166"/>
        <location filename="mainwindow.ui" line="3953"/>
        <source>Prenom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2182"/>
        <source>Date de naissance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2198"/>
        <location filename="mainwindow.ui" line="3722"/>
        <location filename="mainwindow.ui" line="7217"/>
        <location filename="mainwindow.ui" line="7729"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2214"/>
        <location filename="mainwindow.ui" line="3252"/>
        <location filename="mainwindow.ui" line="3873"/>
        <source>tel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2230"/>
        <location filename="mainwindow.ui" line="3985"/>
        <source>Profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2413"/>
        <location filename="mainwindow.ui" line="2792"/>
        <location filename="mainwindow.ui" line="4680"/>
        <location filename="mainwindow.ui" line="6514"/>
        <location filename="mainwindow.ui" line="6639"/>
        <location filename="mainwindow.ui" line="7324"/>
        <location filename="mainwindow.ui" line="8425"/>
        <location filename="mainwindow.ui" line="9329"/>
        <location filename="mainwindow.ui" line="10009"/>
        <location filename="mainwindow.ui" line="10386"/>
        <location filename="mainwindow.ui" line="11615"/>
        <location filename="mainwindow.ui" line="12329"/>
        <source>Ajouter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2555"/>
        <source>Ajouter profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2587"/>
        <location filename="mainwindow.ui" line="3435"/>
        <location filename="mainwindow.ui" line="3487"/>
        <location filename="mainwindow.ui" line="4204"/>
        <location filename="mainwindow.ui" line="8381"/>
        <location filename="mainwindow.ui" line="11821"/>
        <location filename="mainwindow.ui" line="12208"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2600"/>
        <source>nom_profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2613"/>
        <location filename="mainwindow.ui" line="4348"/>
        <source>Salaire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2626"/>
        <location filename="mainwindow.ui" line="4335"/>
        <location filename="mainwindow.ui" line="6565"/>
        <location filename="mainwindow.ui" line="7337"/>
        <location filename="mainwindow.ui" line="7612"/>
        <location filename="mainwindow.ui" line="10417"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2639"/>
        <location filename="mainwindow.ui" line="4361"/>
        <source>Nombre des agents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2928"/>
        <source>Afficher les agents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="2985"/>
        <location filename="mainwindow.ui" line="3350"/>
        <location filename="mainwindow.ui" line="12134"/>
        <source>Chercher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3018"/>
        <location filename="mainwindow.ui" line="3569"/>
        <location filename="mainwindow.ui" line="6847"/>
        <location filename="mainwindow.ui" line="7498"/>
        <location filename="mainwindow.ui" line="8766"/>
        <location filename="mainwindow.ui" line="10644"/>
        <location filename="mainwindow.ui" line="11387"/>
        <source>Imprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3051"/>
        <location filename="mainwindow.ui" line="3383"/>
        <location filename="mainwindow.ui" line="4998"/>
        <location filename="mainwindow.ui" line="6196"/>
        <location filename="mainwindow.ui" line="6984"/>
        <location filename="mainwindow.ui" line="7030"/>
        <location filename="mainwindow.ui" line="7828"/>
        <location filename="mainwindow.ui" line="8678"/>
        <location filename="mainwindow.ui" line="9692"/>
        <location filename="mainwindow.ui" line="10190"/>
        <location filename="mainwindow.ui" line="10554"/>
        <location filename="mainwindow.ui" line="11010"/>
        <location filename="mainwindow.ui" line="11693"/>
        <source>Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3085"/>
        <location filename="mainwindow.ui" line="3602"/>
        <location filename="mainwindow.ui" line="6756"/>
        <location filename="mainwindow.ui" line="7396"/>
        <location filename="mainwindow.ui" line="9736"/>
        <source>Actualiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3159"/>
        <location filename="mainwindow.ui" line="3536"/>
        <location filename="mainwindow.ui" line="5446"/>
        <location filename="mainwindow.ui" line="6312"/>
        <location filename="mainwindow.ui" line="8722"/>
        <source>PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3185"/>
        <location filename="mainwindow.ui" line="3247"/>
        <location filename="mainwindow.ui" line="6006"/>
        <location filename="mainwindow.ui" line="11042"/>
        <location filename="mainwindow.ui" line="11438"/>
        <source>prenom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3198"/>
        <source>email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3232"/>
        <location filename="mainwindow.ui" line="3482"/>
        <source>trier par</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3242"/>
        <location filename="mainwindow.ui" line="6230"/>
        <location filename="mainwindow.ui" line="8211"/>
        <location filename="mainwindow.ui" line="11186"/>
        <location filename="mainwindow.ui" line="11454"/>
        <source>nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3286"/>
        <location filename="mainwindow.ui" line="9647"/>
        <source>Statistique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3293"/>
        <source>Afficher les profils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3448"/>
        <location filename="mainwindow.ui" line="3497"/>
        <source>salaire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3492"/>
        <source>nom profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3502"/>
        <source>nombre des agents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3673"/>
        <source>Modifier agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3809"/>
        <location filename="mainwindow.ui" line="4261"/>
        <location filename="mainwindow.ui" line="4964"/>
        <location filename="mainwindow.ui" line="6138"/>
        <location filename="mainwindow.ui" line="6978"/>
        <location filename="mainwindow.ui" line="7776"/>
        <location filename="mainwindow.ui" line="8478"/>
        <location filename="mainwindow.ui" line="9382"/>
        <location filename="mainwindow.ui" line="10175"/>
        <location filename="mainwindow.ui" line="10206"/>
        <location filename="mainwindow.ui" line="10523"/>
        <location filename="mainwindow.ui" line="10538"/>
        <location filename="mainwindow.ui" line="11235"/>
        <location filename="mainwindow.ui" line="12019"/>
        <source>Modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="3889"/>
        <location filename="mainwindow.ui" line="11202"/>
        <source>date de naissance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4126"/>
        <source>Modifier profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4322"/>
        <source>nom_Profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4486"/>
        <source>GESTION DE TRANSPORT : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4550"/>
        <source>moyens de transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4623"/>
        <source>Ajouter moyen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4701"/>
        <location filename="mainwindow.ui" line="5190"/>
        <source>model :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4722"/>
        <location filename="mainwindow.ui" line="5169"/>
        <source>ref:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4746"/>
        <location filename="mainwindow.ui" line="5214"/>
        <source>confort :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4770"/>
        <location filename="mainwindow.ui" line="5148"/>
        <source>nombres de places :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4824"/>
        <location filename="mainwindow.ui" line="5238"/>
        <source>climatisation :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4906"/>
        <location filename="mainwindow.ui" line="5406"/>
        <source>VOITURE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4911"/>
        <location filename="mainwindow.ui" line="5411"/>
        <source>BUS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="4918"/>
        <source>Afficher moyen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5272"/>
        <location filename="mainwindow.ui" line="5863"/>
        <source>Refreche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5306"/>
        <location filename="mainwindow.ui" line="5966"/>
        <location filename="mainwindow.ui" line="9530"/>
        <source>Rechercher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5311"/>
        <location filename="mainwindow.ui" line="5361"/>
        <location filename="mainwindow.ui" line="5932"/>
        <source>ref</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5316"/>
        <source>modele et confort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5321"/>
        <source>modele et nombre_de_place et confort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5356"/>
        <location filename="mainwindow.ui" line="6064"/>
        <source>Trier </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5366"/>
        <source>modele</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5371"/>
        <source>modele et nombre de place </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5480"/>
        <location filename="mainwindow.ui" line="6346"/>
        <source>IMPRIMER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5486"/>
        <source>réclamation :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5501"/>
        <source>gestion abonnements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5566"/>
        <source>ajouter abonné</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5610"/>
        <source>ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5631"/>
        <source>NOM:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5700"/>
        <source>prenom :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5721"/>
        <source>ref moyen :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5742"/>
        <source>payer :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5824"/>
        <location filename="mainwindow.ui" line="7153"/>
        <source>ajouter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5830"/>
        <source>afficher abonne</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5908"/>
        <location filename="mainwindow.ui" line="5971"/>
        <location filename="mainwindow.ui" line="6069"/>
        <location filename="mainwindow.ui" line="8188"/>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5976"/>
        <source>nom et prenom </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="5981"/>
        <location filename="mainwindow.ui" line="6079"/>
        <source>ref_moy et nom et prenom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6030"/>
        <source>payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6074"/>
        <source>nom et prenom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6387"/>
        <source>Gestion des projets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6421"/>
        <location filename="mainwindow.ui" line="6436"/>
        <source>Gestion des catégories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6526"/>
        <source>id </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6552"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6645"/>
        <location filename="mainwindow.ui" line="7353"/>
        <source>afficher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6688"/>
        <location filename="mainwindow.ui" line="7464"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6790"/>
        <location filename="mainwindow.ui" line="7555"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6803"/>
        <source>Nom à chercher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6853"/>
        <location filename="mainwindow.ui" line="7561"/>
        <source>modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6865"/>
        <source>Id du catégorie à modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6878"/>
        <source>Nouveau nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6891"/>
        <source>Nouveau type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6904"/>
        <source>Nouveau description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="6996"/>
        <source>ID du categorie à supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7165"/>
        <source>Id projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7191"/>
        <source>Emplacement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7204"/>
        <location filename="mainwindow.ui" line="7716"/>
        <source>Lieu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7230"/>
        <location filename="mainwindow.ui" line="7677"/>
        <source>Contenue </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7511"/>
        <source>Nom a chercher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7599"/>
        <source>nouveau Emplacement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7625"/>
        <source>Id projet à modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7638"/>
        <source>nouveau nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7782"/>
        <source>supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7794"/>
        <source>Id du projet à supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="7853"/>
        <source>Gestion de projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8068"/>
        <source>Equipements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8148"/>
        <source>Ajouter  Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8234"/>
        <source>nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8257"/>
        <source>adresse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8280"/>
        <source>prix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8303"/>
        <source>marque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8329"/>
        <source>Nombre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8342"/>
        <source>Adresse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8355"/>
        <location filename="mainwindow.ui" line="11953"/>
        <location filename="mainwindow.ui" line="12224"/>
        <source>Prix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8368"/>
        <source>Marque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8510"/>
        <source>Afficher Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8634"/>
        <source>Acualiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8784"/>
        <source>Organisation par Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8806"/>
        <source>Ajouter Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8915"/>
        <source>  ID                             </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8936"/>
        <source>Nom Bloc                           </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8957"/>
        <source>Equipment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8978"/>
        <source>Type Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="8999"/>
        <source>Numéro                     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9020"/>
        <source>date </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9054"/>
        <source>ID de 6 chiffres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9089"/>
        <source>NOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9123"/>
        <source>equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9156"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9190"/>
        <source>NUMERO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9224"/>
        <source>JJ/MM/AAAA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9245"/>
        <source>Situation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9279"/>
        <source>En marche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9284"/>
        <source>En panne</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9398"/>
        <source>Afficher Equipements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9563"/>
        <source>ID/NOM/PRENOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9588"/>
        <source>Tri par ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9613"/>
        <source>Tri par nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9762"/>
        <source>Stop Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9796"/>
        <source>Parking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="9990"/>
        <source>Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10024"/>
        <source>ID Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10040"/>
        <source>Tel Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10056"/>
        <source>Email Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10072"/>
        <source>Adresse Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10088"/>
        <source>Nom Fournisseur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10169"/>
        <location filename="mainwindow.ui" line="10517"/>
        <source>AJOUTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10262"/>
        <location filename="mainwindow.ui" line="10600"/>
        <source>Afficher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10277"/>
        <source>trier par nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10304"/>
        <source>Recherche par ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10320"/>
        <source>trier par id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10336"/>
        <location filename="mainwindow.ui" line="10628"/>
        <source>Affichage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10367"/>
        <source>Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10401"/>
        <source>Code Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10433"/>
        <source>Montantnet de Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10449"/>
        <source>Date de Devis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10670"/>
        <source>Recherche par code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10683"/>
        <source>Revenu total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10699"/>
        <source>tri croissant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10715"/>
        <source>tri decroissant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10731"/>
        <source>Imp PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10786"/>
        <source>Individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10819"/>
        <source>Logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10852"/>
        <location filename="mainwindow.ui" line="10918"/>
        <source>AJOUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="10885"/>
        <location filename="mainwindow.ui" line="10951"/>
        <source>AFFICHAGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11026"/>
        <location filename="mainwindow.ui" line="11170"/>
        <location filename="mainwindow.ui" line="11422"/>
        <source>cin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11082"/>
        <location filename="mainwindow.ui" line="11470"/>
        <source>idl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11344"/>
        <location filename="mainwindow.ui" line="11648"/>
        <location filename="mainwindow.ui" line="11986"/>
        <location filename="mainwindow.ui" line="12362"/>
        <source>Retour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11486"/>
        <source>date de naissace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11733"/>
        <location filename="mainwindow.ui" line="12176"/>
        <source>NomF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="11861"/>
        <location filename="mainwindow.ui" line="12192"/>
        <source>Secteur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12035"/>
        <source>ID </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12068"/>
        <source>Trier par prix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12101"/>
        <source>Trier par id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="12468"/>
        <source>v1.0.0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="Blocc.cpp" line="51"/>
        <location filename="categorie.cpp" line="106"/>
        <location filename="categorie.cpp" line="121"/>
        <location filename="categorie.cpp" line="137"/>
        <location filename="categorie.cpp" line="150"/>
        <location filename="categorie.cpp" line="163"/>
        <location filename="categorie.cpp" line="174"/>
        <location filename="profil.cpp" line="85"/>
        <location filename="projet.cpp" line="133"/>
        <location filename="projet.cpp" line="151"/>
        <location filename="projet.cpp" line="170"/>
        <location filename="projet.cpp" line="186"/>
        <location filename="projet.cpp" line="202"/>
        <location filename="projet.cpp" line="216"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="52"/>
        <source>NOM_BLOC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="53"/>
        <source>EQUIPMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="54"/>
        <source>TYPE_EQUIPEMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="55"/>
        <source>NUMERO_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="56"/>
        <source>DATE_A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Blocc.cpp" line="57"/>
        <source>SITUATION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="62"/>
        <location filename="abonnement.cpp" line="157"/>
        <location filename="abonnement.cpp" line="176"/>
        <location filename="abonnement.cpp" line="191"/>
        <location filename="fournisseur.cpp" line="113"/>
        <location filename="fournisseur.cpp" line="125"/>
        <location filename="logement.cpp" line="65"/>
        <location filename="logement.cpp" line="98"/>
        <location filename="logement.cpp" line="109"/>
        <location filename="logement.cpp" line="119"/>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="63"/>
        <location filename="abonnement.cpp" line="158"/>
        <location filename="abonnement.cpp" line="177"/>
        <location filename="abonnement.cpp" line="192"/>
        <location filename="fournisseur.cpp" line="114"/>
        <location filename="fournisseur.cpp" line="126"/>
        <location filename="individus.cpp" line="70"/>
        <source>nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="64"/>
        <location filename="abonnement.cpp" line="159"/>
        <location filename="abonnement.cpp" line="178"/>
        <location filename="abonnement.cpp" line="193"/>
        <location filename="individus.cpp" line="71"/>
        <source>prenom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="65"/>
        <location filename="abonnement.cpp" line="160"/>
        <location filename="abonnement.cpp" line="179"/>
        <location filename="abonnement.cpp" line="194"/>
        <source>ref_moy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="abonnement.cpp" line="66"/>
        <location filename="abonnement.cpp" line="161"/>
        <location filename="abonnement.cpp" line="180"/>
        <location filename="abonnement.cpp" line="195"/>
        <source>payement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="254"/>
        <source>CIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="255"/>
        <location filename="categorie.cpp" line="107"/>
        <location filename="categorie.cpp" line="122"/>
        <location filename="categorie.cpp" line="138"/>
        <location filename="categorie.cpp" line="151"/>
        <location filename="categorie.cpp" line="164"/>
        <location filename="categorie.cpp" line="175"/>
        <location filename="projet.cpp" line="134"/>
        <location filename="projet.cpp" line="152"/>
        <location filename="projet.cpp" line="171"/>
        <location filename="projet.cpp" line="187"/>
        <location filename="projet.cpp" line="203"/>
        <location filename="projet.cpp" line="217"/>
        <source>NOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="256"/>
        <source>PRENOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="257"/>
        <source>DATE_NAISSANCE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="258"/>
        <location filename="projet.cpp" line="137"/>
        <location filename="projet.cpp" line="155"/>
        <location filename="projet.cpp" line="174"/>
        <location filename="projet.cpp" line="190"/>
        <location filename="projet.cpp" line="206"/>
        <location filename="projet.cpp" line="220"/>
        <source>EMAIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="259"/>
        <source>TEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="agents.cpp" line="260"/>
        <location filename="profil.cpp" line="86"/>
        <source>NOM_PROFIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="categorie.cpp" line="108"/>
        <location filename="categorie.cpp" line="123"/>
        <location filename="categorie.cpp" line="139"/>
        <location filename="categorie.cpp" line="152"/>
        <location filename="categorie.cpp" line="165"/>
        <location filename="categorie.cpp" line="176"/>
        <source>TYPE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="categorie.cpp" line="109"/>
        <location filename="categorie.cpp" line="124"/>
        <location filename="categorie.cpp" line="140"/>
        <location filename="categorie.cpp" line="153"/>
        <location filename="categorie.cpp" line="166"/>
        <location filename="categorie.cpp" line="177"/>
        <location filename="profil.cpp" line="88"/>
        <location filename="projet.cpp" line="139"/>
        <location filename="projet.cpp" line="157"/>
        <location filename="projet.cpp" line="176"/>
        <location filename="projet.cpp" line="192"/>
        <location filename="projet.cpp" line="208"/>
        <location filename="projet.cpp" line="222"/>
        <source>DESCRIPTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="35"/>
        <location filename="devis.cpp" line="59"/>
        <location filename="devis.cpp" line="93"/>
        <source>CODE_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="36"/>
        <location filename="devis.cpp" line="60"/>
        <location filename="devis.cpp" line="95"/>
        <source>MONTNET_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="37"/>
        <location filename="devis.cpp" line="61"/>
        <location filename="devis.cpp" line="96"/>
        <source>DESC_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="devis.cpp" line="38"/>
        <location filename="devis.cpp" line="62"/>
        <location filename="devis.cpp" line="94"/>
        <source>DATE_DEV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="38"/>
        <location filename="fournisseur.cpp" line="63"/>
        <location filename="fournisseur.cpp" line="83"/>
        <source>ID_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="39"/>
        <location filename="fournisseur.cpp" line="64"/>
        <location filename="fournisseur.cpp" line="84"/>
        <source>NOM_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="40"/>
        <location filename="fournisseur.cpp" line="85"/>
        <source>ADRESSE_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="41"/>
        <location filename="fournisseur.cpp" line="67"/>
        <location filename="fournisseur.cpp" line="86"/>
        <source>EMAIL_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="42"/>
        <location filename="fournisseur.cpp" line="65"/>
        <location filename="fournisseur.cpp" line="87"/>
        <source>TEL_FOUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="66"/>
        <source>ADRESSE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="115"/>
        <location filename="fournisseur.cpp" line="127"/>
        <source>adresse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="116"/>
        <location filename="fournisseur.cpp" line="128"/>
        <source>email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fournisseur.cpp" line="117"/>
        <location filename="fournisseur.cpp" line="129"/>
        <source>telephone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="61"/>
        <location filename="gestionmoyen.cpp" line="155"/>
        <location filename="gestionmoyen.cpp" line="174"/>
        <location filename="gestionmoyen.cpp" line="189"/>
        <source>ref</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="62"/>
        <location filename="gestionmoyen.cpp" line="156"/>
        <location filename="gestionmoyen.cpp" line="175"/>
        <location filename="gestionmoyen.cpp" line="190"/>
        <source>modele</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="63"/>
        <location filename="gestionmoyen.cpp" line="157"/>
        <location filename="gestionmoyen.cpp" line="176"/>
        <location filename="gestionmoyen.cpp" line="191"/>
        <source>confort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="64"/>
        <location filename="gestionmoyen.cpp" line="158"/>
        <location filename="gestionmoyen.cpp" line="177"/>
        <location filename="gestionmoyen.cpp" line="192"/>
        <source>nombre_de_place</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gestionmoyen.cpp" line="65"/>
        <location filename="gestionmoyen.cpp" line="159"/>
        <location filename="gestionmoyen.cpp" line="178"/>
        <location filename="gestionmoyen.cpp" line="193"/>
        <source>climatisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="individus.cpp" line="69"/>
        <source>cin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="individus.cpp" line="72"/>
        <source>date de naissance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="individus.cpp" line="73"/>
        <source>idl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logement.cpp" line="66"/>
        <location filename="logement.cpp" line="99"/>
        <location filename="logement.cpp" line="110"/>
        <location filename="logement.cpp" line="120"/>
        <source>nomf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logement.cpp" line="67"/>
        <location filename="logement.cpp" line="100"/>
        <location filename="logement.cpp" line="111"/>
        <location filename="logement.cpp" line="121"/>
        <source>secteur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="logement.cpp" line="68"/>
        <location filename="logement.cpp" line="101"/>
        <location filename="logement.cpp" line="112"/>
        <location filename="logement.cpp" line="122"/>
        <source>price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="32"/>
        <source>database is open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="33"/>
        <source>connection successful.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="37"/>
        <source>database is not open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.cpp" line="38"/>
        <source>connection failed.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="222"/>
        <source>Ajouter un employe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="223"/>
        <source>employe ajouté.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="235"/>
        <source>Ajouter un employé</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="236"/>
        <location filename="mainwindow.cpp" line="499"/>
        <location filename="mainwindow.cpp" line="1412"/>
        <location filename="mainwindow.cpp" line="1444"/>
        <location filename="mainwindow.cpp" line="1473"/>
        <location filename="mainwindow.cpp" line="1597"/>
        <location filename="mainwindow.cpp" line="1633"/>
        <location filename="mainwindow.cpp" line="1662"/>
        <source>Erreur !.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="485"/>
        <location filename="mainwindow.cpp" line="498"/>
        <source>Ajouter profil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="486"/>
        <source>profil ajouté.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1405"/>
        <location filename="mainwindow.cpp" line="1411"/>
        <source>Ajouter une Categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1406"/>
        <source>Categorie ajoutée.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1437"/>
        <location filename="mainwindow.cpp" line="1443"/>
        <source>Modifier une Categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1438"/>
        <source>Categorie modifiée.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1466"/>
        <location filename="mainwindow.cpp" line="1472"/>
        <source>Supprimer une Categorie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1467"/>
        <source>Categorie supprimée.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1538"/>
        <location filename="mainwindow.cpp" line="1726"/>
        <source>PDF echoue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1538"/>
        <location filename="mainwindow.cpp" line="1726"/>
        <source>click cancel to exit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1590"/>
        <location filename="mainwindow.cpp" line="1596"/>
        <source>Ajouter un Projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1591"/>
        <source>Projet ajouté.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1626"/>
        <location filename="mainwindow.cpp" line="1632"/>
        <source>Modifier un Projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1627"/>
        <source>Projet modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1655"/>
        <location filename="mainwindow.cpp" line="1661"/>
        <source>Supprimer un Projet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1656"/>
        <source>Projet supprimé.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1911"/>
        <location filename="mainwindow.cpp" line="1915"/>
        <location filename="mainwindow.cpp" line="1920"/>
        <location filename="mainwindow.cpp" line="1925"/>
        <location filename="mainwindow.cpp" line="1930"/>
        <location filename="mainwindow.cpp" line="1936"/>
        <location filename="mainwindow.cpp" line="1942"/>
        <location filename="mainwindow.cpp" line="1953"/>
        <location filename="mainwindow.cpp" line="1959"/>
        <source>Ajouter un Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1912"/>
        <location filename="mainwindow.cpp" line="2196"/>
        <source>ID Doit contenir 6 chifres.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1916"/>
        <location filename="mainwindow.cpp" line="1921"/>
        <location filename="mainwindow.cpp" line="1931"/>
        <location filename="mainwindow.cpp" line="2200"/>
        <location filename="mainwindow.cpp" line="2207"/>
        <location filename="mainwindow.cpp" line="2211"/>
        <location filename="mainwindow.cpp" line="2216"/>
        <location filename="mainwindow.cpp" line="2221"/>
        <source>Veuillez remplir tous les cases.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1926"/>
        <source>Veuillez saisir correctement le numero.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1937"/>
        <source>Veuillez saisir la date sous forme jj/mm/aaaa.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1943"/>
        <source>Veuillez saisir la categorie.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1954"/>
        <source>Client ajouté .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1960"/>
        <location filename="mainwindow.cpp" line="2015"/>
        <location filename="mainwindow.cpp" line="2061"/>
        <source>Erreur.
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2007"/>
        <location filename="mainwindow.cpp" line="2014"/>
        <source>Supprimer un Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2008"/>
        <source>Client sumprié .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2053"/>
        <source>Modifier un Bloc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2054"/>
        <source>Client Modifié .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2060"/>
        <source>Modifier un BLoc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2108"/>
        <source>Sélectionner un Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2109"/>
        <location filename="mainwindow.cpp" line="2327"/>
        <source>Erreur .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2195"/>
        <location filename="mainwindow.cpp" line="2199"/>
        <location filename="mainwindow.cpp" line="2206"/>
        <location filename="mainwindow.cpp" line="2210"/>
        <location filename="mainwindow.cpp" line="2215"/>
        <location filename="mainwindow.cpp" line="2220"/>
        <location filename="mainwindow.cpp" line="2230"/>
        <location filename="mainwindow.cpp" line="2236"/>
        <source>Ajouter Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2231"/>
        <source>Equipement ajoutée .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2237"/>
        <source>ERooR .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2288"/>
        <location filename="mainwindow.cpp" line="2295"/>
        <source>Modifier Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2289"/>
        <source>Equipement Modifié .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2296"/>
        <source>ereur .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2319"/>
        <location filename="mainwindow.cpp" line="2326"/>
        <source>Supprimer Equipement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2320"/>
        <source>Equipement supprimé .
Click Cancel to exit .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2484"/>
        <location filename="mainwindow.cpp" line="2573"/>
        <location filename="mainwindow.cpp" line="3009"/>
        <source>erreur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2485"/>
        <location filename="mainwindow.cpp" line="2574"/>
        <source>Ajout non effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2770"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2770"/>
        <source> Erreur idl necessite 4 chiffres.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2778"/>
        <source>ajouter individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2778"/>
        <source>individus ajouté.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2801"/>
        <source>supprimer individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2801"/>
        <source>individus supprimé.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2831"/>
        <location filename="mainwindow.cpp" line="2838"/>
        <source>modifier individus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2832"/>
        <source>individus modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2839"/>
        <location filename="mainwindow.cpp" line="3052"/>
        <source>Erreur.
click cancel to exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="3009"/>
        <source>id incomplet.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="3016"/>
        <source>ajouter logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="3016"/>
        <source>logement ajouté.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="3044"/>
        <location filename="mainwindow.cpp" line="3051"/>
        <source>modifier logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="3045"/>
        <source>logement modifié.
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="3073"/>
        <source>supprimer logement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="3073"/>
        <source>logement supprimé.
click cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profil.cpp" line="87"/>
        <source>SALAIRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="profil.cpp" line="89"/>
        <source>NB_AGNETS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="projet.cpp" line="135"/>
        <location filename="projet.cpp" line="153"/>
        <location filename="projet.cpp" line="172"/>
        <location filename="projet.cpp" line="188"/>
        <location filename="projet.cpp" line="204"/>
        <location filename="projet.cpp" line="218"/>
        <source>EMPLACEMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="projet.cpp" line="136"/>
        <location filename="projet.cpp" line="154"/>
        <location filename="projet.cpp" line="173"/>
        <location filename="projet.cpp" line="189"/>
        <location filename="projet.cpp" line="205"/>
        <location filename="projet.cpp" line="219"/>
        <source>LIEU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="projet.cpp" line="138"/>
        <location filename="projet.cpp" line="156"/>
        <location filename="projet.cpp" line="175"/>
        <location filename="projet.cpp" line="191"/>
        <location filename="projet.cpp" line="207"/>
        <location filename="projet.cpp" line="221"/>
        <source>CONTENUE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <location filename="mainwindow.cpp" line="2479"/>
        <location filename="mainwindow.cpp" line="2568"/>
        <source>Ajout effectué
Click Cancel to exit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>arduinoo</name>
    <message>
        <location filename="arduinoo.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="26"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="50"/>
        <source>CLOSE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="63"/>
        <source>OPEN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="86"/>
        <source>Fix parking spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="99"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="106"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="123"/>
        <source>Ticket ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="144"/>
        <source>CHARGE 8h = 2dt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="163"/>
        <source>                         parking smart municipality     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="206"/>
        <source>BALANCE:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="228"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="arduinoo.ui" line="247"/>
        <source>8h</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>stati</name>
    <message>
        <location filename="stati.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="stati.ui" line="45"/>
        <location filename="stati.ui" line="78"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statistiques</name>
    <message>
        <location filename="statistiques.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
