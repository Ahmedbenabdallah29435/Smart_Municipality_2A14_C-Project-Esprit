<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="fr">
<context>
    <name>MainWindow</name>
    <message>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <source>Municipality</source>
        <translation></translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation></translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation></translation>
    </message>
    <message>
        <source>Close</source>
        <translation></translation>
    </message>
    <message>
        <source>| HOME</source>
        <translation></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation></translation>
    </message>
    <message>
        <source>Save</source>
        <translation></translation>
    </message>
    <message>
        <source>New</source>
        <translation></translation>
    </message>
    <message>
        <source>Created by: Wanderson M. Pimenta</source>
        <translation></translation>
    </message>
    <message>
        <source>USER</source>
        <translation></translation>
    </message>
    <message>
        <source>PASSWORD</source>
        <translation></translation>
    </message>
    <message>
        <source>SAVE USER</source>
        <translation></translation>
    </message>
    <message>
        <source>CONNECT</source>
        <translation></translation>
    </message>
    <message>
        <source>Welcome to our project</source>
        <translation></translation>
    </message>
    <message>
        <source>gestion projet</source>
        <translation></translation>
    </message>
    <message>
        <source>gestion de transport</source>
        <translation></translation>
    </message>
    <message>
        <source>gestion des equipements</source>
        <translation></translation>
    </message>
    <message>
        <source>gestion financiere</source>
        <translation></translation>
    </message>
    <message>
        <source>gestion idvidus</source>
        <translation></translation>
    </message>
    <message>
        <source>gestion des agents</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter agent</source>
        <translation></translation>
    </message>
    <message>
        <source>CIN</source>
        <translation></translation>
    </message>
    <message>
        <source>Nom</source>
        <translation></translation>
    </message>
    <message>
        <source>Prenom</source>
        <translation></translation>
    </message>
    <message>
        <source>Date de naissance</source>
        <translation></translation>
    </message>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>tel</source>
        <translation></translation>
    </message>
    <message>
        <source>Profil</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter profil</source>
        <translation></translation>
    </message>
    <message>
        <source>ID</source>
        <translation></translation>
    </message>
    <message>
        <source>nom_profil</source>
        <translation></translation>
    </message>
    <message>
        <source>Salaire</source>
        <translation></translation>
    </message>
    <message>
        <source>Description</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre des agents</source>
        <translation></translation>
    </message>
    <message>
        <source>Afficher les agents</source>
        <translation></translation>
    </message>
    <message>
        <source>Chercher</source>
        <translation></translation>
    </message>
    <message>
        <source>Imprimer</source>
        <translation></translation>
    </message>
    <message>
        <source>Supprimer</source>
        <translation></translation>
    </message>
    <message>
        <source>Actualiser</source>
        <translation></translation>
    </message>
    <message>
        <source>PDF</source>
        <translation></translation>
    </message>
    <message>
        <source>prenom</source>
        <translation></translation>
    </message>
    <message>
        <source>email</source>
        <translation></translation>
    </message>
    <message>
        <source>trier par</source>
        <translation></translation>
    </message>
    <message>
        <source>nom</source>
        <translation></translation>
    </message>
    <message>
        <source>Statistique</source>
        <translation></translation>
    </message>
    <message>
        <source>Afficher les profils</source>
        <translation></translation>
    </message>
    <message>
        <source>salaire</source>
        <translation></translation>
    </message>
    <message>
        <source>nom profil</source>
        <translation></translation>
    </message>
    <message>
        <source>nombre des agents</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier agent</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier</source>
        <translation></translation>
    </message>
    <message>
        <source>date de naissance</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier profil</source>
        <translation></translation>
    </message>
    <message>
        <source>nom_Profil</source>
        <translation></translation>
    </message>
    <message>
        <source>GESTION DE TRANSPORT : </source>
        <translation></translation>
    </message>
    <message>
        <source>moyens de transport</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter moyen</source>
        <translation></translation>
    </message>
    <message>
        <source>model :</source>
        <translation></translation>
    </message>
    <message>
        <source>ref:</source>
        <translation></translation>
    </message>
    <message>
        <source>confort :</source>
        <translation></translation>
    </message>
    <message>
        <source>nombres de places :</source>
        <translation></translation>
    </message>
    <message>
        <source>climatisation :</source>
        <translation></translation>
    </message>
    <message>
        <source>VOITURE</source>
        <translation></translation>
    </message>
    <message>
        <source>BUS</source>
        <translation></translation>
    </message>
    <message>
        <source>Afficher moyen</source>
        <translation></translation>
    </message>
    <message>
        <source>Refreche</source>
        <translation></translation>
    </message>
    <message>
        <source>Rechercher</source>
        <translation></translation>
    </message>
    <message>
        <source>ref</source>
        <translation></translation>
    </message>
    <message>
        <source>modele et confort</source>
        <translation></translation>
    </message>
    <message>
        <source>modele et nombre_de_place et confort</source>
        <translation></translation>
    </message>
    <message>
        <source>Trier </source>
        <translation></translation>
    </message>
    <message>
        <source>modele</source>
        <translation></translation>
    </message>
    <message>
        <source>modele et nombre de place </source>
        <translation></translation>
    </message>
    <message>
        <source>IMPRIMER</source>
        <translation></translation>
    </message>
    <message>
        <source>réclamation :</source>
        <translation></translation>
    </message>
    <message>
        <source>gestion abonnements</source>
        <translation></translation>
    </message>
    <message>
        <source>ajouter abonné</source>
        <translation></translation>
    </message>
    <message>
        <source>ID:</source>
        <translation></translation>
    </message>
    <message>
        <source>NOM:</source>
        <translation></translation>
    </message>
    <message>
        <source>prenom :</source>
        <translation></translation>
    </message>
    <message>
        <source>ref moyen :</source>
        <translation></translation>
    </message>
    <message>
        <source>payer :</source>
        <translation></translation>
    </message>
    <message>
        <source>ajouter</source>
        <translation></translation>
    </message>
    <message>
        <source>afficher abonne</source>
        <translation></translation>
    </message>
    <message>
        <source>id</source>
        <translation></translation>
    </message>
    <message>
        <source>nom et prenom </source>
        <translation></translation>
    </message>
    <message>
        <source>ref_moy et nom et prenom</source>
        <translation></translation>
    </message>
    <message>
        <source>payment</source>
        <translation></translation>
    </message>
    <message>
        <source>nom et prenom</source>
        <translation></translation>
    </message>
    <message>
        <source>Gestion des projets</source>
        <translation></translation>
    </message>
    <message>
        <source>Gestion des catégories</source>
        <translation></translation>
    </message>
    <message>
        <source>id </source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation></translation>
    </message>
    <message>
        <source>afficher</source>
        <translation></translation>
    </message>
    <message>
        <source>Id</source>
        <translation></translation>
    </message>
    <message>
        <source>Search</source>
        <translation></translation>
    </message>
    <message>
        <source>Nom à chercher</source>
        <translation></translation>
    </message>
    <message>
        <source>modifier</source>
        <translation></translation>
    </message>
    <message>
        <source>Id du catégorie à modifier</source>
        <translation></translation>
    </message>
    <message>
        <source>Nouveau nom</source>
        <translation></translation>
    </message>
    <message>
        <source>Nouveau type</source>
        <translation></translation>
    </message>
    <message>
        <source>Nouveau description</source>
        <translation></translation>
    </message>
    <message>
        <source>ID du categorie à supprimer</source>
        <translation></translation>
    </message>
    <message>
        <source>Id projet</source>
        <translation></translation>
    </message>
    <message>
        <source>Emplacement</source>
        <translation></translation>
    </message>
    <message>
        <source>Lieu</source>
        <translation></translation>
    </message>
    <message>
        <source>Contenue </source>
        <translation></translation>
    </message>
    <message>
        <source>Nom a chercher</source>
        <translation></translation>
    </message>
    <message>
        <source>nouveau Emplacement</source>
        <translation></translation>
    </message>
    <message>
        <source>Id projet à modifier</source>
        <translation></translation>
    </message>
    <message>
        <source>nouveau nom</source>
        <translation></translation>
    </message>
    <message>
        <source>supprimer</source>
        <translation></translation>
    </message>
    <message>
        <source>Id du projet à supprimer</source>
        <translation></translation>
    </message>
    <message>
        <source>Gestion de projet</source>
        <translation></translation>
    </message>
    <message>
        <source>Equipements</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter  Equipement</source>
        <translation></translation>
    </message>
    <message>
        <source>nombre</source>
        <translation></translation>
    </message>
    <message>
        <source>adresse</source>
        <translation></translation>
    </message>
    <message>
        <source>prix</source>
        <translation></translation>
    </message>
    <message>
        <source>marque</source>
        <translation></translation>
    </message>
    <message>
        <source>Nombre</source>
        <translation></translation>
    </message>
    <message>
        <source>Adresse</source>
        <translation></translation>
    </message>
    <message>
        <source>Prix</source>
        <translation></translation>
    </message>
    <message>
        <source>Marque</source>
        <translation></translation>
    </message>
    <message>
        <source>Afficher Equipement</source>
        <translation></translation>
    </message>
    <message>
        <source>Acualiser</source>
        <translation></translation>
    </message>
    <message>
        <source>Organisation par Bloc</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter Bloc</source>
        <translation></translation>
    </message>
    <message>
        <source>  ID                             </source>
        <translation></translation>
    </message>
    <message>
        <source>Nom Bloc                           </source>
        <translation></translation>
    </message>
    <message>
        <source>Equipment</source>
        <translation></translation>
    </message>
    <message>
        <source>Type Equipement</source>
        <translation></translation>
    </message>
    <message>
        <source>Numéro                     </source>
        <translation></translation>
    </message>
    <message>
        <source>date </source>
        <translation></translation>
    </message>
    <message>
        <source>ID de 6 chiffres</source>
        <translation></translation>
    </message>
    <message>
        <source>NOM</source>
        <translation></translation>
    </message>
    <message>
        <source>equipement</source>
        <translation></translation>
    </message>
    <message>
        <source>type</source>
        <translation></translation>
    </message>
    <message>
        <source>NUMERO</source>
        <translation></translation>
    </message>
    <message>
        <source>JJ/MM/AAAA</source>
        <translation></translation>
    </message>
    <message>
        <source>Situation</source>
        <translation></translation>
    </message>
    <message>
        <source>En marche</source>
        <translation></translation>
    </message>
    <message>
        <source>En panne</source>
        <translation></translation>
    </message>
    <message>
        <source>Afficher Equipements</source>
        <translation></translation>
    </message>
    <message>
        <source>ID/NOM/PRENOM</source>
        <translation></translation>
    </message>
    <message>
        <source>Tri par ID</source>
        <translation></translation>
    </message>
    <message>
        <source>Tri par nom</source>
        <translation></translation>
    </message>
    <message>
        <source>Start Music</source>
        <translation></translation>
    </message>
    <message>
        <source>Stop Music</source>
        <translation></translation>
    </message>
    <message>
        <source>Fournisseur</source>
        <translation></translation>
    </message>
    <message>
        <source>ID Fournisseur</source>
        <translation></translation>
    </message>
    <message>
        <source>Tel Fournisseur</source>
        <translation></translation>
    </message>
    <message>
        <source>Email Fournisseur</source>
        <translation></translation>
    </message>
    <message>
        <source>Adresse Fournisseur</source>
        <translation></translation>
    </message>
    <message>
        <source>Nom Fournisseur</source>
        <translation></translation>
    </message>
    <message>
        <source>AJOUTER</source>
        <translation></translation>
    </message>
    <message>
        <source>1</source>
        <translation></translation>
    </message>
    <message>
        <source>2</source>
        <translation></translation>
    </message>
    <message>
        <source>3</source>
        <translation></translation>
    </message>
    <message>
        <source>4</source>
        <translation></translation>
    </message>
    <message>
        <source>5</source>
        <translation></translation>
    </message>
    <message>
        <source>6</source>
        <translation></translation>
    </message>
    <message>
        <source>7</source>
        <translation></translation>
    </message>
    <message>
        <source>Adr. Fournisseur</source>
        <translation></translation>
    </message>
    <message>
        <source>1354841</source>
        <translation></translation>
    </message>
    <message>
        <source>azoebfakz</source>
        <translation></translation>
    </message>
    <message>
        <source>azefazf</source>
        <translation></translation>
    </message>
    <message>
        <source>azhef@gmail.com</source>
        <translation></translation>
    </message>
    <message>
        <source>58796431</source>
        <translation></translation>
    </message>
    <message>
        <source>Recherche par ID</source>
        <translation></translation>
    </message>
    <message>
        <source>Afficher</source>
        <translation></translation>
    </message>
    <message>
        <source>Affichage</source>
        <translation></translation>
    </message>
    <message>
        <source>Par nom</source>
        <translation></translation>
    </message>
    <message>
        <source>Par adresse</source>
        <translation></translation>
    </message>
    <message>
        <source>Par tel</source>
        <translation></translation>
    </message>
    <message>
        <source>Devis</source>
        <translation></translation>
    </message>
    <message>
        <source>Code Devis</source>
        <translation></translation>
    </message>
    <message>
        <source>Montantnet de Devis</source>
        <translation></translation>
    </message>
    <message>
        <source>Date de Devis</source>
        <translation></translation>
    </message>
    <message>
        <source>Recherche par code</source>
        <translation></translation>
    </message>
    <message>
        <source>Par date</source>
        <translation></translation>
    </message>
    <message>
        <source>Par montant net</source>
        <translation></translation>
    </message>
    <message>
        <source>Individus</source>
        <translation></translation>
    </message>
    <message>
        <source>Logement</source>
        <translation></translation>
    </message>
    <message>
        <source>AJOUT</source>
        <translation></translation>
    </message>
    <message>
        <source>AFFICHAGE</source>
        <translation></translation>
    </message>
    <message>
        <source>cin</source>
        <translation></translation>
    </message>
    <message>
        <source>idl</source>
        <translation></translation>
    </message>
    <message>
        <source>Retour</source>
        <translation></translation>
    </message>
    <message>
        <source>date de naissace</source>
        <translation></translation>
    </message>
    <message>
        <source>NomF</source>
        <translation></translation>
    </message>
    <message>
        <source>Secteur</source>
        <translation></translation>
    </message>
    <message>
        <source>ID </source>
        <translation></translation>
    </message>
    <message>
        <source>Trier par prix</source>
        <translation></translation>
    </message>
    <message>
        <source>Trier par id</source>
        <translation></translation>
    </message>
    <message>
        <source>v1.0.0</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>ID</source>
        <translation></translation>
    </message>
    <message>
        <source>NOM_BLOC</source>
        <translation></translation>
    </message>
    <message>
        <source>EQUIPMENT</source>
        <translation></translation>
    </message>
    <message>
        <source>TYPE_EQUIPEMENT</source>
        <translation></translation>
    </message>
    <message>
        <source>NUMERO_FOUR</source>
        <translation></translation>
    </message>
    <message>
        <source>DATE_A</source>
        <translation></translation>
    </message>
    <message>
        <source>SITUATION</source>
        <translation></translation>
    </message>
    <message>
        <source>id</source>
        <translation></translation>
    </message>
    <message>
        <source>nom</source>
        <translation></translation>
    </message>
    <message>
        <source>prenom</source>
        <translation></translation>
    </message>
    <message>
        <source>ref_moy</source>
        <translation></translation>
    </message>
    <message>
        <source>payement</source>
        <translation></translation>
    </message>
    <message>
        <source>CIN</source>
        <translation></translation>
    </message>
    <message>
        <source>NOM</source>
        <translation></translation>
    </message>
    <message>
        <source>PRENOM</source>
        <translation></translation>
    </message>
    <message>
        <source>DATE_NAISSANCE</source>
        <translation></translation>
    </message>
    <message>
        <source>EMAIL</source>
        <translation></translation>
    </message>
    <message>
        <source>TEL</source>
        <translation></translation>
    </message>
    <message>
        <source>NOM_PROFIL</source>
        <translation></translation>
    </message>
    <message>
        <source>TYPE</source>
        <translation></translation>
    </message>
    <message>
        <source>DESCRIPTION</source>
        <translation></translation>
    </message>
    <message>
        <source>CODE_DEV</source>
        <translation></translation>
    </message>
    <message>
        <source>MONTNET_DEV</source>
        <translation></translation>
    </message>
    <message>
        <source>DESC_DEV</source>
        <translation></translation>
    </message>
    <message>
        <source>DATE_DEV</source>
        <translation></translation>
    </message>
    <message>
        <source>ID_FOUR</source>
        <translation></translation>
    </message>
    <message>
        <source>NOM_FOUR</source>
        <translation></translation>
    </message>
    <message>
        <source>ADRESSE_FOUR</source>
        <translation></translation>
    </message>
    <message>
        <source>EMAIL_FOUR</source>
        <translation></translation>
    </message>
    <message>
        <source>TEL_FOUR</source>
        <translation></translation>
    </message>
    <message>
        <source>ADRESSE</source>
        <translation></translation>
    </message>
    <message>
        <source>ref</source>
        <translation></translation>
    </message>
    <message>
        <source>modele</source>
        <translation></translation>
    </message>
    <message>
        <source>confort</source>
        <translation></translation>
    </message>
    <message>
        <source>nombre_de_place</source>
        <translation></translation>
    </message>
    <message>
        <source>climatisation</source>
        <translation></translation>
    </message>
    <message>
        <source>cin</source>
        <translation></translation>
    </message>
    <message>
        <source>date de naissance</source>
        <translation></translation>
    </message>
    <message>
        <source>idl</source>
        <translation></translation>
    </message>
    <message>
        <source>nomf</source>
        <translation></translation>
    </message>
    <message>
        <source>secteur</source>
        <translation></translation>
    </message>
    <message>
        <source>price</source>
        <translation></translation>
    </message>
    <message>
        <source>database is open</source>
        <translation></translation>
    </message>
    <message>
        <source>connection successful.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>database is not open</source>
        <translation></translation>
    </message>
    <message>
        <source>connection failed.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter un employe</source>
        <translation></translation>
    </message>
    <message>
        <source>employe ajouté.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter un employé</source>
        <translation></translation>
    </message>
    <message>
        <source>Erreur !.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter profil</source>
        <translation></translation>
    </message>
    <message>
        <source>profil ajouté.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter une Categorie</source>
        <translation></translation>
    </message>
    <message>
        <source>Categorie ajoutée.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier une Categorie</source>
        <translation></translation>
    </message>
    <message>
        <source>Categorie modifiée.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Supprimer une Categorie</source>
        <translation></translation>
    </message>
    <message>
        <source>Categorie supprimée.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>PDF echoue</source>
        <translation></translation>
    </message>
    <message>
        <source>click cancel to exit!</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter un Projet</source>
        <translation></translation>
    </message>
    <message>
        <source>Projet ajouté.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier un Projet</source>
        <translation></translation>
    </message>
    <message>
        <source>Projet modifié.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Supprimer un Projet</source>
        <translation></translation>
    </message>
    <message>
        <source>Projet supprimé.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter un Bloc</source>
        <translation></translation>
    </message>
    <message>
        <source>ID Doit contenir 6 chifres.
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Veuillez remplir tous les cases.
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Veuillez saisir correctement le numero.
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Veuillez saisir la date sous forme jj/mm/aaaa.
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Veuillez saisir la categorie.
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Client ajouté .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Erreur.
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Supprimer un Client</source>
        <translation></translation>
    </message>
    <message>
        <source>Client sumprié .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier un Bloc</source>
        <translation></translation>
    </message>
    <message>
        <source>Client Modifié .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier un BLoc</source>
        <translation></translation>
    </message>
    <message>
        <source>Sélectionner un Client</source>
        <translation></translation>
    </message>
    <message>
        <source>Erreur .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajouter Equipement</source>
        <translation></translation>
    </message>
    <message>
        <source>Equipement ajoutée .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>ERooR .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Modifier Equipement</source>
        <translation></translation>
    </message>
    <message>
        <source>Equipement Modifié .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>ereur .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>Supprimer Equipement</source>
        <translation></translation>
    </message>
    <message>
        <source>Equipement supprimé .
Click Cancel to exit .</source>
        <translation></translation>
    </message>
    <message>
        <source>erreur</source>
        <translation></translation>
    </message>
    <message>
        <source>Ajout non effectué
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <source> Erreur idl necessite 4 chiffres.
click cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>ajouter individus</source>
        <translation></translation>
    </message>
    <message>
        <source>individus ajouté.
click cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>supprimer individus</source>
        <translation></translation>
    </message>
    <message>
        <source>individus supprimé.
click cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>modifier individus</source>
        <translation></translation>
    </message>
    <message>
        <source>individus modifié.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Erreur.
click cancel to exit</source>
        <translation></translation>
    </message>
    <message>
        <source>id incomplet.
click cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>ajouter logement</source>
        <translation></translation>
    </message>
    <message>
        <source>logement ajouté.
click cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>modifier logement</source>
        <translation></translation>
    </message>
    <message>
        <source>logement modifié.
Click Cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>supprimer logement</source>
        <translation></translation>
    </message>
    <message>
        <source>logement supprimé.
click cancel to exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>SALAIRE</source>
        <translation></translation>
    </message>
    <message>
        <source>NB_AGNETS</source>
        <translation></translation>
    </message>
    <message>
        <source>EMPLACEMENT</source>
        <translation></translation>
    </message>
    <message>
        <source>LIEU</source>
        <translation></translation>
    </message>
    <message>
        <source>CONTENUE</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Ajout effectué
Click Cancel to exit.</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>statistiques</name>
    <message>
        <source>MainWindow</source>
        <translation></translation>
    </message>
</context>
</TS>
